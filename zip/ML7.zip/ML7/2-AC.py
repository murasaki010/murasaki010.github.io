import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt


# =========================
# Actor-Critic Network
# =========================
class ActorCriticNet(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, 128),
            nn.ReLU()
        )
        self.actor = nn.Sequential(
            nn.Linear(128, act_dim),
            nn.Softmax(dim=-1)
        )
        self.critic = nn.Linear(128, 1)

    def forward(self, x):
        x = self.shared(x)
        probs = self.actor(x)
        value = self.critic(x)
        return probs, value


# =========================
# Actor-Critic Agent
# =========================
class ACAgent:
    def __init__(
        self,
        obs_dim,
        act_dim,
        lr=3e-4,
        gamma=0.99,
        entropy_coef=0.01
    ):
        self.net = ActorCriticNet(obs_dim, act_dim)
        self.optimizer = optim.Adam(self.net.parameters(), lr=lr)

        self.gamma = gamma
        self.entropy_coef = entropy_coef

    def select_action(self, obs):
        obs_t = torch.tensor(obs, dtype=torch.float32)
        probs, value = self.net(obs_t)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        return action.item(), dist.log_prob(action), value

    def update(self, logp, value, reward, next_value, done, entropy):
        # TD error (Advantage)
        td_target = reward + self.gamma * next_value * (1 - done)
        advantage = td_target - value

        actor_loss = -logp * advantage.detach()
        critic_loss = advantage.pow(2)
        entropy_loss = -self.entropy_coef * entropy

        loss = actor_loss + critic_loss + entropy_loss

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# =========================
# Training Loop
# =========================
def train_actor_critic(
    env_name="MountainCar-v0",
    episodes=1500
):
    env = gym.make(env_name)
    agent = ACAgent(
        obs_dim=env.observation_space.shape[0],
        act_dim=env.action_space.n
    )

    reward_log = []

    for ep in range(episodes):
        obs, _ = env.reset()
        done = False
        ep_reward = 0

        while not done:
            action, logp, value = agent.select_action(obs)
            next_obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # =========================
            # Reward Shaping
            # =========================
            position, velocity = next_obs
            shaped_reward = (
                reward
                + 2.0 * position
                + 0.5 * abs(velocity)
            )
            # =========================

            _, next_value = agent.net(
                torch.tensor(next_obs, dtype=torch.float32)
            )

            probs, _ = agent.net(torch.tensor(obs, dtype=torch.float32))
            dist = torch.distributions.Categorical(probs)
            entropy = dist.entropy()

            agent.update(
                logp=logp,
                value=value,
                reward=shaped_reward,
                next_value=next_value,
                done=done,
                entropy=entropy
            )

            obs = next_obs
            ep_reward += reward  # 原始 reward 评估

        reward_log.append(ep_reward)

        if (ep + 1) % 50 == 0:
            print(
                f"Episode {ep+1:4d} | "
                f"Avg Reward (50): {np.mean(reward_log[-50:]):.2f}"
            )

    env.close()

    # =========================
    # Visualization
    # =========================
    plt.figure(figsize=(8, 5))
    plt.plot(reward_log, label="Episode Reward")
    plt.xlabel("Episode")
    plt.ylabel("Return")
    plt.title("Actor-Critic on MountainCar-v0 (with Reward Shaping)")
    plt.legend()
    plt.grid()
    plt.savefig("actor_critic_mountaincar_reward.png")
    plt.show()


if __name__ == "__main__":
    train_actor_critic()
