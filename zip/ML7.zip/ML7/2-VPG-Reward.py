import gymnasium as gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# =========================
# Policy Network
# =========================
class PolicyNet(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, act_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        return self.net(x)


# =========================
# VPG Agent
# =========================
class VPGAgent:
    def __init__(self, obs_dim, act_dim, lr=3e-3, gamma=0.99, entropy_coef=0.01):
        self.policy = PolicyNet(obs_dim, act_dim)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr)
        self.gamma = gamma
        self.entropy_coef = entropy_coef

    def select_action(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32)
        probs = self.policy(obs)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        return action.item(), dist.log_prob(action), dist.entropy()

    def update(self, trajectory):
        log_probs, rewards, entropies = zip(*trajectory)

        # Discounted returns (NO normalization)
        returns = []
        G = 0
        for r in reversed(rewards):
            G = r + self.gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)

        loss = 0
        for log_p, Gt, ent in zip(log_probs, returns, entropies):
            loss += -log_p * Gt - self.entropy_coef * ent

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# =========================
# Training Loop
# =========================
def train_vpg(
    env_name="MountainCar-v0",
    episodes=800
):
    env = gym.make(env_name)
    agent = VPGAgent(
        obs_dim=env.observation_space.shape[0],
        act_dim=env.action_space.n
    )

    reward_log = []

    for ep in range(episodes):
        obs, _ = env.reset()
        trajectory = []
        ep_reward = 0

        done = False
        while not done:
            action, logp, entropy = agent.select_action(obs)
            next_obs, reward, terminated, truncated, _ = env.step(action)

            # ===============================
            # Reward Shaping (CRITICAL)
            # ===============================
            position, velocity = next_obs
            shaped_reward = (
                reward
                + 5.0 * (position + 0.5)   # position shaping (directional)
                + 1.0 * abs(velocity)      # velocity shaping (momentum)
            )
            # ===============================

            trajectory.append((logp, shaped_reward, entropy))
            ep_reward += shaped_reward

            obs = next_obs
            done = terminated or truncated

        agent.update(trajectory)
        reward_log.append(ep_reward)

        if (ep + 1) % 50 == 0:
            avg_reward = np.mean(reward_log[-50:])
            print(f"Episode {ep+1}\tAvg Shaped Reward (50): {avg_reward:.2f}")

    env.close()
    return agent, reward_log


if __name__ == "__main__":
    train_vpg()
