import os
import torch
import torch.nn as nn
from torch.distributions import Categorical
import random
import numpy as np
import gymnasium as gym

# =========================
# Device
# =========================
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("Device set to:", device)

# =========================
# Rollout Buffer
# =========================
class RolloutBuffer:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []

    def clear(self):
        self.actions.clear()
        self.states.clear()
        self.logprobs.clear()
        self.rewards.clear()
        self.is_terminals.clear()


# =========================
# Actor-Critic Network
# =========================
class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim):
        super().__init__()

        self.actor = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, action_dim),
            nn.Softmax(dim=-1)
        )

        self.critic = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )

    def act(self, state):
        probs = self.actor(state)
        dist = Categorical(probs)
        action = dist.sample()
        return action.detach(), dist.log_prob(action).detach()

    def evaluate(self, states, actions):
        probs = self.actor(states)
        dist = Categorical(probs)

        logprobs = dist.log_prob(actions)
        entropy = dist.entropy()
        values = self.critic(states)

        return logprobs, values.squeeze(-1), entropy


# =========================
# PPO Agent
# =========================
class PPO:
    def __init__(self, state_dim, action_dim, hidden_dim,
                 lr_actor, lr_critic, gamma, K_epochs, eps_clip):

        self.gamma = gamma
        self.eps_clip = eps_clip
        self.K_epochs = K_epochs

        self.buffer = RolloutBuffer()

        self.policy = ActorCritic(state_dim, action_dim, hidden_dim).to(device)
        self.policy_old = ActorCritic(state_dim, action_dim, hidden_dim).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())

        self.optimizer = torch.optim.Adam([
            {'params': self.policy.actor.parameters(), 'lr': lr_actor},
            {'params': self.policy.critic.parameters(), 'lr': lr_critic}
        ])

        self.mse_loss = nn.MSELoss()

    def select_action(self, state):
        with torch.no_grad():
            state = torch.as_tensor(state, dtype=torch.float32, device=device)
            action, logprob = self.policy_old.act(state)

        self.buffer.states.append(state)
        self.buffer.actions.append(action)
        self.buffer.logprobs.append(logprob)

        return action.item()

    def update(self):
        # Monte Carlo return
        returns = []
        discounted = 0

        for reward, done in zip(reversed(self.buffer.rewards),
                                reversed(self.buffer.is_terminals)):
            if done:
                discounted = 0
            discounted = reward + self.gamma * discounted
            returns.insert(0, discounted)

        returns = torch.tensor(returns, dtype=torch.float32, device=device)
        returns = (returns - returns.mean()) / (returns.std() + 1e-7)

        states = torch.stack(self.buffer.states).detach()
        actions = torch.stack(self.buffer.actions).detach()
        old_logprobs = torch.stack(self.buffer.logprobs).detach()

        for _ in range(self.K_epochs):
            logprobs, values, entropy = self.policy.evaluate(states, actions)

            ratios = torch.exp(logprobs - old_logprobs)
            advantages = returns - values.detach()

            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - self.eps_clip, 1 + self.eps_clip) * advantages

            loss = (
                -torch.min(surr1, surr2)
                + 0.5 * self.mse_loss(values, returns)
                - 0.01 * entropy
            ).mean()

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

        self.policy_old.load_state_dict(self.policy.state_dict())
        self.buffer.clear()


# =========================
# Training
# =========================
def train():
    env_name = "MountainCar-v0"
    env = gym.make(env_name)

    seed = 1
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    ppo = PPO(
        state_dim=state_dim,
        action_dim=action_dim,
        hidden_dim=64,
        lr_actor=3e-4,
        lr_critic=1e-3,
        gamma=0.99,
        K_epochs=40,
        eps_clip=0.2
    )

    max_reward = -200
    num_episodes = 5000
    update_every = 5

    for ep in range(num_episodes):
        state, _ = env.reset()   # ✅ FIXED
        ep_reward = 0

        for t in range(300):
            action = ppo.select_action(state)

            state, reward, terminated, truncated, _ = env.step(action)  # ✅ FIXED
            done = terminated or truncated

            ppo.buffer.rewards.append(reward)
            ppo.buffer.is_terminals.append(done)

            ep_reward += reward
            if done:
                break

        if ep % update_every == 0:
            ppo.update()

        max_reward = max(max_reward, ep_reward)

        if ep % 10 == 0:
            print(f"Episode {ep:5d} | Reward: {ep_reward:6.1f} | Max: {max_reward:6.1f}")

        if ep_reward > -110:
            os.makedirs("data", exist_ok=True)
            torch.save(ppo.policy.actor.state_dict(), f"data/PPO_MC_ep{ep}.pth")

    env.close()


if __name__ == "__main__":
    train()
