import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt


# =========================
# Policy Network
# =========================
class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 128),
            nn.ReLU(),
            nn.Linear(128, act_dim)
        )

    def forward(self, x):
        return torch.softmax(self.net(x), dim=-1)


# =========================
# Vanilla Policy Gradient Agent
# =========================
class VPGAgent:
    def __init__(self, obs_dim, act_dim, lr=3e-3, gamma=0.99, entropy_coef=0.05):
        self.policy = PolicyNetwork(obs_dim, act_dim)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr)
        self.gamma = gamma
        self.entropy_coef = entropy_coef

    def select_action(self, obs):
        obs_t = torch.tensor(obs, dtype=torch.float32)
        probs = self.policy(obs_t)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        return action.item(), dist.log_prob(action), dist.entropy()

    def compute_returns(self, rewards):
        returns = []
        G = 0
        for r in reversed(rewards):
            G = r + self.gamma * G
            returns.insert(0, G)
        return torch.tensor(returns, dtype=torch.float32)

    def update(self, log_probs, entropies, rewards):
        returns = self.compute_returns(rewards)

        loss = 0
        for logp, ent, G in zip(log_probs, entropies, returns):
            loss += -logp * G - self.entropy_coef * ent

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# =========================
# Training Loop
# =========================
def train_vpg(episodes=3000):
    env = gym.make("MountainCar-v0")
    agent = VPGAgent(
        obs_dim=env.observation_space.shape[0],
        act_dim=env.action_space.n
    )

    reward_history = []

    for ep in range(episodes):
        obs, _ = env.reset()
        done = False

        log_probs = []
        entropies = []
        rewards = []
        ep_reward = 0

        while not done:
            action, logp, entropy = agent.select_action(obs)
            next_obs, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # =========================
            # Strong Reward Shaping
            # =========================
            position, velocity = next_obs
            shaped_reward = (
                reward
                + 1.0 * position
                + 0.5 * abs(velocity)
            )

            log_probs.append(logp)
            entropies.append(entropy)
            rewards.append(shaped_reward)

            obs = next_obs
            ep_reward += reward  # 原始 reward 评估

        agent.update(log_probs, entropies, rewards)
        reward_history.append(ep_reward)

        if (ep + 1) % 100 == 0:
            print(
                f"Episode {ep+1:4d} | "
                f"Avg Reward (100): {np.mean(reward_history[-100:]):.2f}"
            )

    env.close()

    # =========================
    # Visualization
    # =========================
    plt.figure(figsize=(8, 5))
    plt.plot(reward_history, label="Episode Reward")
    plt.xlabel("Episode")
    plt.ylabel("Return")
    plt.title("Vanilla Policy Gradient on MountainCar (Strong Reward Shaping)")
    plt.legend()
    plt.grid()
    plt.savefig("vpg_mountaincar_reward.png")
    plt.show()


if __name__ == "__main__":
    train_vpg()
