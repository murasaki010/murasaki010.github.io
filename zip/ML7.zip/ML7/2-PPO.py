import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt


# =========================
# Utils
# =========================
def normalize_obs(obs):
    return np.array([obs[0] / 1.2, obs[1] / 0.07], dtype=np.float32)


# =========================
# Actor-Critic
# =========================
class ActorCritic(nn.Module):
    def __init__(self):
        super().__init__()
        self.shared = nn.Sequential(
            nn.Linear(2, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU()
        )
        self.actor = nn.Linear(128, 3)
        self.critic = nn.Linear(128, 1)

    def forward(self, x):
        x = self.shared(x)
        return self.actor(x), self.critic(x).squeeze(-1)


# =========================
# PPO Training
# =========================
def train_ppo(episodes=2500):
    env = gym.make("MountainCar-v0")
    net = ActorCritic()
    optimizer = optim.Adam(net.parameters(), lr=3e-4)

    gamma = 0.99
    lam = 0.95
    clip_eps = 0.35          # ★ 放宽 clip
    entropy_coef = 0.08      # ★ 强探索
    reward_log = []

    for ep in range(episodes):
        obs, _ = env.reset()
        obs = normalize_obs(obs)

        logps, values, rewards, entropies = [], [], [], []
        done = False
        ep_reward = 0

        while not done:
            obs_t = torch.tensor(obs)
            logits, value = net(obs_t)
            dist = torch.distributions.Categorical(logits=logits)

            action = dist.sample()
            logp = dist.log_prob(action)
            entropy = dist.entropy()

            next_obs, reward, terminated, truncated, _ = env.step(action.item())
            done = terminated or truncated

            # ===== STRONG Reward Shaping =====
            pos, vel = next_obs
            shaped_reward = -1 + 10 * pos + 5 * abs(vel)

            logps.append(logp)
            values.append(value)
            rewards.append(shaped_reward)
            entropies.append(entropy)

            obs = normalize_obs(next_obs)
            ep_reward += reward

        # ===== GAE =====
        returns, advs = [], []
        G, gae = 0, 0
        values = values + [torch.tensor(0.0)]

        for t in reversed(range(len(rewards))):
            G = rewards[t] + gamma * G
            delta = rewards[t] + gamma * values[t+1] - values[t]
            gae = delta + gamma * lam * gae
            returns.insert(0, G)
            advs.insert(0, gae)

        returns = torch.tensor(returns)
        advs = torch.tensor(advs)
        advs = (advs - advs.mean()) / (advs.std() + 1e-8)

        logps = torch.stack(logps)
        values = torch.stack(values[:-1])
        entropies = torch.stack(entropies)

        # ===== PPO Update (single batch) =====
        logits, new_values = net(torch.stack(
            [torch.tensor(normalize_obs(env.reset()[0])) for _ in range(len(logps))]
        ))

        ratio = torch.exp(logps - logps.detach())
        surr1 = ratio * advs
        surr2 = torch.clamp(ratio, 1 - clip_eps, 1 + clip_eps) * advs

        actor_loss = -torch.min(surr1, surr2).mean()
        critic_loss = (returns - values).pow(2).mean()
        entropy_loss = entropies.mean()

        loss = actor_loss + 0.3 * critic_loss - entropy_coef * entropy_loss

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        reward_log.append(ep_reward)

        if (ep + 1) % 50 == 0:
            print(f"Episode {ep+1:4d} | Avg Reward (50): {np.mean(reward_log[-50:]):.2f}")

    # ===== Plot =====
    plt.plot(reward_log)
    plt.xlabel("Episode")
    plt.ylabel("Return")
    plt.title("PPO on MountainCar-v0 (Engineered)")
    plt.grid()
    plt.savefig("ppo_mountaincar.png")
    plt.show()

    env.close()


if __name__ == "__main__":
    train_ppo()
